<?php
$response = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include('conx.php');
      $name=$_POST['name']; 
      $email=$_POST['email']; 
      $number=$_POST['number']; 
      $message=$_POST['message']; 
    $errors=[];
    if(empty($name)){
        $errors[] ='name is a required field';
    }
    if(empty($email)){
        $errors[] ='email is a required field';
    }
         if(empty($number)){
        $errors[] ='number is a required field';
    }  
    if(empty($message)){
        $errors[] ='message is a required field';
    }
    if(empty($errors)){
       try{
         $statment=$conn->prepare("insert into contacts (name,email,number,message) values(?,?,?,?)");
        $statment->bind_param('ssss',$name,$email,$number,$message);
        $statment->execute();
       }
       catch(Exception $e){
        $errors[]='error: ' . $e->getMessage();
       }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Contact - Autofix</title>
    <link rel="stylesheet" href="./assets/css/style.css" />
    <style>
        body { font-family: sans-serif; background: #f4f4f4; }
        .contact-form { max-width: 600px; margin: 40px auto; background: #fff; padding: 24px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; margin-bottom: 6px; font-weight: bold; }
        .form-input, textarea { width: 100%; padding: 10px; border: 1px solid #aaa; border-radius: 4px; }
        .btn { margin-top: 10px; background: #1a73e8; color: #fff; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; }
        .btn:hover { background: #155ab6; }
        .response { margin: 20px auto; padding: 15px; max-width: 600px; background: #fff; border-radius: 8px; }
    </style>
</head>
<body>

<!-- <?php if (!empty($errors)) { echo '<div><ul><li>' . implode('</li><li>', $errors) . '</li></ul></div>'; } ?> -->
 

<form  method="POST" class="contact-form">
    <h2>Contact Us</h2>
    <div class="form-group">
        <label for="name" class="form-label">Your Name</label>
        <input type="text" id="name" name="name" class="form-input" required />
    </div>
    <div class="form-group">
        <label for="email" class="form-label">Your Email</label>
        <input type="email" id="email" name="email" class="form-input" required />
    </div>
    <div class="form-group">
        <label for="number" class="form-label">Your Number</label>
        <input type="text" id="number" name="number" class="form-input" required />
    </div>
    <div class="form-group">
        <label for="message" class="form-label">Message</label>
        <textarea id="message" name="message" rows="5" class="form-input" required></textarea>
    </div>
    <button type="submit" class="btn">Send Message</button>
</form>

</body>
</html>