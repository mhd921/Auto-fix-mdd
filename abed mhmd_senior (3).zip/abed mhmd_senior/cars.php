<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Autofix - Auto Maintenance & Repair Service</title>
  <meta name="title" content="Autofix - Auto Maintenance & Repair Service">
  <meta name="description" content="This is a vehicle repair html template made by codewithsadee">
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;600;700&family=Mulish&display=swap"
    rel="stylesheet">
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@40,600,0,0" />
  <link rel="stylesheet" href="./assets/css/style.css">
  <link rel="preload" as="image" href="./assets/images/hero-banner.png">
  <link rel="preload" as="image" href="./assets/images/hero-bg.jpg">
  <link rel="stylesheet" href="booking.css">
</head>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  include('conx.php');
  $name = $_POST['name'];
  $car = $_POST['car'];
  $preferred_date = $_POST['date'];
  $errors = [];
  if (empty($name)) {
    $errors[] = 'name is a required field';
  }
  if (empty($car)) {
    $errors[] = 'car mode is a required field';
  }
  if (empty($preferred_date)) {
    $errors[] = 'preferred date is a required field';
  }
  if (empty($errors)) {
    try {
      $statment = $conn->prepare("insert into booking_cars (name,car,preferred_date) values(?,?,?)");
      $statment->bind_param('sss', $name, $car, $preferred_date);
      $statment->execute();
      $statment->close();
      // exit;
    } catch (Exception $e) {
      $errors[] = 'error: ' . $e->getMessage();
    }
  }
}
?>

<body>
  <header class="header" style="background-color: hsl(222, 47%, 15%); height: 90px;">
    <div class="container">

      <a href="#" class="logo">
        <img src="./assets/images/logo.png" width="128" height="63" alt="autofix home">
      </a>

      <nav class="navbar" data-navbar>
        <ul class="navbar-list">

          <li>
            <a href="Home.html" class="navbar-link">Home</a>
          </li>

          <li>
            <a href="booking.html" class="navbar-link">Booking</a>
          </li>


          <li>
            <a href="about.html" class="navbar-link">About</a>
          </li>

          <li>
            <a href="cars.html" class="navbar-link">Our Cars</a>
          </li>

          <li>
            <a href="service.html" class="navbar-link">Services</a>
          </li>

          <li>
            <a href="contact.html" class="navbar-link">Contact</a>
          </li>

          <li>
            <a href="#" class="navbar-link">LogIn</a>
          </li>

        </ul>
      </nav>
      <button class="nav-toggle-btn" aria-label="toggle menu" data-nav-toggler>
        <span class="nav-toggle-icon icon-1"></span>
        <span class="nav-toggle-icon icon-2"></span>
        <span class="nav-toggle-icon icon-3"></span>
      </button>

    </div>
  </header>


  <input type="text" id="searchInput" placeholder="Search by car model...">

  <!-- <script>
    function redirectToPage() {
      window.location.href = "credits.html";
    }

    function filterCars() {
      var input = document.getElementById("searchInput");
      var filter = input.value.toUpperCase();
      var cars = Array.from(document.getElementsByClassName("car")); // Convert HTMLCollection to an array

      cars.forEach(function (car) {
        var carModel = car.getElementsByClassName("car-model")[0];
        var modelText = carModel.innerText.toUpperCase();
        if (modelText.indexOf(filter) > -1) {
          car.style.display = "";
        } else {
          car.style.display = "none";
        }
      });
    }


    document.getElementById("searchInput").addEventListener("input", filterCars);
  </script>
  <script>
    function redirectToPage() {
      window.location.href = "credits.html";
    }

  </script> -->


  <div class="container">
    <div class="cars">
      <div class="car">
        <img src="car5.jpg">
        <h1 class="car-model">Bmw 2023</h1>
        <p>The BMW 2023 Serie 7 is a luxury sedan with an 8-cylinder twin-turbo engine, premium leather seats, and
          cutting-edge technology. It delivers exceptional comfort, performance, and prestige.</p>
        <div class="hr"></div>
        <div class="sales">
          <p><a href="#" class="more-info-link">More Info</a></p>
        </div>
        <button class="booking-btn">booking</button>

      </div>

    </div>
    <div class="cars">
      <div class="car">
        <img src="car2.jpg">
        <h1 class="car-model">Honda 2020</h1>
        <p>The Honda 2020 is known for its reliability and fuel efficiency. It comes with a comfortable cabin, modern
          infotainment system, and a reputation for low maintenance costs, making it a great choice for families and
          commuters.</p>
        <div class="hr"></div>
        <div class="sales">
          <p> <a href="#" class="more-info-link">More Info</a></p>
        </div>

        <button class="booking-btn">booking</button>

      </div>
    </div>
    <div class="cars">
      <div class="car">
        <img src="car3.jpg">
        <h1 class="car-model">Ford 2022</h1>
        <p>The Ford 2022 offers a powerful twin-turbo engine, sporty design, and advanced driver assistance features.
          Its spacious interior and robust performance make it ideal for both city driving and long journeys.</p>
        <div class="hr"></div>
        <div class="sales">
          <p> <a href="#" class="more-info-link">More Info</a></p>
        </div>
        <button class="booking-btn">booking</button>

      </div>
    </div>
    <div class="cars">
      <div class="car">
        <img src="car4.jpg">
        <h1 class="car-model">Hyundai 2022</h1>
        <p>The Hyundai 2022 features a modern design, advanced safety technology, and a fuel-efficient engine. It offers
          a comfortable interior, user-friendly infotainment system, and excellent reliability, making it a smart choice
          for daily commuting and family trips.</p>
        <div class="hr"></div>
        <div class="sales">
          <p> <a href="#" class="more-info-link">More Info</a></p>
        </div>
        <button class="booking-btn">booking</button>

      </div>
    </div>
    <div class="cars">
      <div class="car">
        <img src="rover2025.jpg">
        <h1 class="car-model">Rover2025</h1>
        <p>The Rover 2025 combines rugged off-road capability with modern luxury. It features a robust 4-cylinder
          engine, advanced all-wheel drive, and a spacious, tech-filled interior.</p>
        <div class="hr"></div>
        <div class="sales">
          <p><a href="#" class="more-info-link">More Info</a></p>
        </div>
        <button class="booking-btn">booking</button>

      </div>
    </div>
    <div class="cars">
      <div class="car">
        <img src="car1.jpg">
        <h1 class="car-model">toyota 2024</h1>
        <p>The Toyota 2024 X5 offers a reliable 6-cylinder engine, advanced safety features, and a comfortable ride. It
          is perfect for families and those seeking a dependable, modern vehicle.</p>
        <div class="hr"></div>
        <div class="sales">
          <p><a href="#" class="more-info-link">More Info</a></p>
        </div>
        <button class="booking-btn">booking</button>

      </div>
    </div>
  </div>

  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> -->
  <div id="loginModal" class="modal">
    
  </div>
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> -->
  <div id="bookingModal"
    style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.6); z-index:9999; align-items:center; justify-content:center;">
    <div
      style="background:#232946; color:#fff; border-radius:10px; max-width:400px; width:90%; margin:auto; padding:32px 24px; position:relative;">
      <span id="closeBooking"
        style="position:absolute; top:12px; right:18px; font-size:1.5rem; cursor:pointer;">&times;</span>
      <h2 style="color:#eebbc3; margin-bottom:18px; text-align:center;">Book Your Car</h2>
      <form id="bookingForm" method="POST">
        <label for="name">Your Name</label>
        <input type="text" id="name" name="name" required
          style="width:100%;padding:8px 10px;margin-bottom:10px;border:1px solid #eebbc3;border-radius:4px;background:#fff;color:#232946;">
        <label for="car">Car Model</label>
        <input type="text" id="car" name="car" required
          style="width:100%;padding:8px 10px;margin-bottom:10px;border:1px solid #eebbc3;border-radius:4px;background:#fff;color:#232946;">
        <label for="date">Preferred Date</label>
        <input type="date" id="date" name="date" required
          style="width:100%;padding:8px 10px;margin-bottom:10px;border:1px solid #eebbc3;border-radius:4px;background:#fff;color:#232946;">
        <button type="submit"
          style="width:100%;padding:10px 0;background:#eebbc3;color:#232946;border:none;border-radius:6px;font-size:1rem;font-weight:600;cursor:pointer;margin-top:10px;">Book
          Now</button>
      </form>
      <div id="bookingSuccess" style="display:none; text-align:center; color:#eebbc3; margin-top:18px;">Thank you! Your
        booking has been received.</div>
    </div>
  </div>
  <!-- Car Info Modal -->
  <!-- <div id="carInfoModal"
    style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.6); z-index:9999; align-items:center; justify-content:center;">
    <div
      style="background:#232946; color:#fff; border-radius:10px; max-width:400px; width:90%; margin:auto; padding:32px 24px; position:relative;">
      <span id="closeCarInfo"
        style="position:absolute; top:12px; right:18px; font-size:1.5rem; cursor:pointer;">&times;</span>
      <h2 id="carInfoTitle" style="color:#eebbc3; margin-bottom:12px; text-align:center;"></h2>
      <p id="carInfoDesc" style="margin-bottom:10px;"></p>
      <div id="carInfoSales" style="color:#eebbc3; margin-bottom:10px;"></div>
      <img id="carInfoImg" src="" alt="Car Image"
        style="width:100%;height:150px;object-fit:cover;border-radius:6px;margin-bottom:10px;">
    </div>
  </div> -->
  <script src="./assets/js/script.js"></script>
</body>



</html>