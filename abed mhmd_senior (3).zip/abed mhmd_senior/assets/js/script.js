// 'use strict';



// /**
//  * MOBILE NAVBAR TOGGLE
//  */

// const navbar = document.querySelector("[data-navbar]");
// const navToggler = document.querySelector("[data-nav-toggler]");

// navToggler.addEventListener("click", function () {
//   navbar.classList.toggle("active");
//   this.classList.toggle("active");
// });

// document.addEventListener('DOMContentLoaded', function () {
//   document.querySelectorAll('.read-more-btn').forEach(function (btn) {
//     btn.addEventListener('click', function (e) {
//       e.preventDefault();
//       const moreText = btn.parentElement.querySelector('.more-text');
//       if (moreText.style.display === 'none' || moreText.style.display === '') {
//         moreText.style.display = 'inline';
//         btn.textContent = 'Read less';
//       } else {
//         moreText.style.display = 'none';
//         btn.textContent = 'Read more';
//       }
//     });
//   });
// });

// // Show modal on LogIn click
// document.querySelectorAll('.navbar-link').forEach(function (link) {
//   if (link.textContent.trim().toLowerCase() === 'login') {
//     link.addEventListener('click', function (e) {
//       e.preventDefault();
//       document.getElementById('loginModal').style.display = 'block';
//       document.getElementById('loginFormSection').style.display = 'block';
//       document.getElementById('registerFormSection').style.display = 'none';
//     });
//   }
// });
// // Close modal
// document.getElementById('closeLogin').addEventListener('click', () => {
//   document.getElementById('loginModal').style.display = 'none';
// })
// // Close modal when clicking outside the modal content
// window.onclick = function (event) {
//   var modal = document.getElementById('loginModal');
//   if (event.target === modal) {
//     modal.style.display = 'none';
//   }
// };
// // Switch to registration form
// document.getElementById('showRegister').onclick = function () {
//   document.getElementById('loginFormSection').style.display = 'none';
//   document.getElementById('registerFormSection').style.display = 'block';
// };
// // Switch to login form
// document.getElementById('showLogin').onclick = function () {
//   document.getElementById('registerFormSection').style.display = 'none';
//   document.getElementById('loginFormSection').style.display = 'block';
// };
// // Handle login form submit
// document.getElementById('loginForm').onsubmit = function (e) {
//   e.preventDefault();
//   alert('Logged in as ' + document.getElementById('login-username').value);
//   document.getElementById('loginModal').style.display = 'none';
// };
// // Handle registration form submit
// document.getElementById('registerForm').onsubmit = function (e) {
//   e.preventDefault();
//   alert('Registered as ' + document.getElementById('register-username').value);
//   document.getElementById('loginModal').style.display = 'none';
// };

// // // Show modal when any booking button is clicked
// // document.querySelectorAll('.booking-btn').forEach(function (btn) {
// //   btn.onclick = () => {
// //     document.getElementById('bookingModal').style.display = 'block';
// //     // Optionally, fill car model automatically:
// //     var carModel = btn.closest('.car').querySelector('.car-model').innerText;
// //     document.getElementById('car').value = carModel;
// //   };
// // });



// // Show modal when any booking button is clicked
// document.querySelectorAll('.booking-btn').forEach(function (btn) {
//   btn.addEventListener('click', () => {
//     console.log('clicked')
//     document.getElementById('bookingModal').style.display = 'block';
//     var carModel = btn.closest('.car').querySelector('.car-model').innerText;
//     document.getElementById('car').value = carModel;
//   })
// });



// // Close modal
// document.getElementById('closeBooking').onclick = function () {
//   document.getElementById('bookingModal').style.display = 'none';
//   document.getElementById('bookingForm').style.display = 'block';
//   document.getElementById('bookingSuccess').style.display = 'none';
// };

// // Hide modal when clicking outside the form
// document.getElementById('bookingModal').onclick = function (e) {
//   e.preventDefault()
//   if (e.target === this) {
//     this.style.display = 'none';
//     document.getElementById('bookingForm').style.display = 'block';
//     document.getElementById('bookingSuccess').style.display = 'none';
//   }
// };

// // Handle form submit (just show success message)
document.getElementById('bookingForm').addEventListener('submit', (e) => {
  // e.preventDefault();
  // e.stopPropagation()
  console.log('hello')
  // this.querySelector('button[type="submit"]').disabled = true; // disable to prevent double clicks

  // this.submit();
  document.getElementById('bookingForm').style.display = 'none';
  document.getElementById('bookingSuccess').style.display = 'block';
})


// // Show car info modal when "More Info" is clicked
// document.querySelectorAll('.more-info-link').forEach(function (link) {
//   link.onclick = function (e) {
//     e.preventDefault();
//     var carDiv = link.closest('.car');
//     var title = carDiv.querySelector('.car-model').innerText;
//     var desc = carDiv.querySelector('p').innerText;
//     var sales = carDiv.querySelector('.sales p').innerText;
//     var imgSrc = carDiv.querySelector('img').getAttribute('src');
//     document.getElementById('carInfoTitle').innerText = title;
//     document.getElementById('carInfoDesc').innerText = desc;
//     document.getElementById('carInfoSales').innerText = sales;
//     document.getElementById('carInfoImg').src = imgSrc;
//     document.getElementById('carInfoModal').style.display = 'flex';
//   };
// });

// // Close car info modal
// document.getElementById('closeCarInfo').onclick = function () {
//   document.getElementById('carInfoModal').style.display = 'none';
// };
// // Hide modal when clicking outside the form
// document.getElementById('carInfoModal').onclick = function (e) {
//   if (e.target === this) {
//     this.style.display = 'none';
//   }
// };

document.querySelectorAll('.booking-btn').forEach(function (btn) {
  btn.addEventListener('click', () => {
    console.log('clicked')
    document.getElementById('bookingModal').style.display = 'block';
    var carModel = btn.closest('.car').querySelector('.car-model').innerText;
    document.getElementById('car').value = carModel;
  })
});
  const moreInfoLinks = document.querySelectorAll(".more-info-link");
  const infoModal = document.getElementById("infoModal");
  const infoContent = document.getElementById("infoContent");
  const closeInfoModal = document.getElementById("closeInfoModal");

  moreInfoLinks.forEach(link => {
    link.addEventListener("click", function(event) {
      event.preventDefault();
      const car = this.closest(".car");
      const img = car.querySelector("img").src;
      const title = car.querySelector(".car-model").innerText;
      const desc = car.querySelector("p").innerText;

      infoContent.innerHTML = `
        <img src="${img}" style="width:100%; max-height:400px; object-fit:cover; border-radius:10px; margin-bottom:20px;">
        <h1 style="color:#eebbc3;">${title}</h1>
        <p style="font-size:18px; line-height:1.6; margin-top:10px;">${desc}</p>
      `;
      infoModal.style.display = "block";
    });
  });

  closeInfoModal.addEventListener("click", function() {
    infoModal.style.display = "none";
  });

  // إغلاق النافذة إذا ضغط المستخدم خارجها
  window.addEventListener("click", function(event) {
    if (event.target === infoModal) {
      infoModal.style.display = "none";
    }
  });

